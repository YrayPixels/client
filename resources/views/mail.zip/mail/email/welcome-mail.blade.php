<x-mail::message>
    Hello {{ $user->name }}

    <div>
        <p>
            Thanks for creating an account with GAPA Naija. Your registered email address is
            <span style="font-weight: bold">{{ $user->email }}</span>. You can access your account area to view orders,
            change your password and more at <a href="gapaautoparts.com/home">https://gapaautoparts.com/home</a>
        </p>
    </div>
    <p>We look forward to seeing you soon and also purchasing from us.</p>
    <p>For any question, kindly check our Faq or send a mail to <a href="mailto::contact@gapaautoparts.com">
            contact@gapaautoparts.com</a> or you can chat with our live chat directly on the website</p>
    <i>the details are shown below</i>
    <div>


        Thanks,<br>
        {{ config('app.name') }}
</x-mail::message>
