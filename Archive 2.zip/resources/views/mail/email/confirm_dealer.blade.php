<div style="border:1px solid rgb(186, 182, 182); padding:20px; background:rgb(233, 231, 231);">

    <div>
        <h6>Hi, {{ $dealer->first_name ?? '' }}, </h6>
        <p>Your enrollement for GAPA Dealership program is received and awaiting approval.
            On approval you'll receive a confirmation mail with your dealer ID.
        </p>
    </div>
    <div style="text-align:end;">
        Thanks
        GAPA,
    </div>
</div>
