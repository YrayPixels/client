<div style="border:1px solid rgb(186, 182, 182); padding:20px; background:rgb(233, 231, 231);">

    <div>
        <div>
            <h3>Hi {{ $dealer->first_name ?? '' }}
                your dealership account with dealer id {{ $dealer->code ?? '' }} has been suspend
                for violating the rules here is your dealer_id</h3>
        </div>
    </div>
    <div>
        <div>
            <h3>Hi {{ $dealer->first_name ?? '' }} </h3>
            <p>Welcome to GapaAutos Dealers Program</p>

            <p> your dealership account with dealer id {{ $dealer->code ?? '' }} has been suspend
                for violating the rules here is your dealer id</p>

            <h1>{{ $dealer->code ?? '' }}</h1>
        </div>
    </div>

    Thanks,<br>
    {{ config('app.name') }}
</div>
