<div style="border:1px solid rgb(186, 182, 182); padding:20px; background:rgb(233, 231, 231);">

    <div>
        <h3>Hi {{ $dealer->first_name ?? '' }} </h3>
        <p>Welcome to GapaAutos Dealers Program</p>

        <p> your dealership account has been approved here is your dealer_id</p>

        <h1>{{ $dealer->code ?? '' }}</h1>
    </div>
    <div style="text-align:end;">
        Thanks
        GAPA,
    </div>
</div>
