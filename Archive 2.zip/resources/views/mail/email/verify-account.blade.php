<div style="border:1px solid rgb(186, 182, 182); padding:20px; background:rgb(233, 231, 231);">
    Hello {{ $user->name ?? '' }}
    <div>
        <p>
            Here is your OTP.
        <h1 style="font-weight: bold">{{ $user->token ?? ' ' }}</h1>

        Thanks,<br>
        {{ config('app.name') }}
    </div>
</div>
